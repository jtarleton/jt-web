+-------------------------------------+
|         APACHE LOG PARSER           |
+-------------------------------------+
|            VERSION 1.0              |
+-------------------------------------+
|              AUTHOR                 | 
|      altmannmarcelo@gmail.com       |
+-------------------------------------+

USAGE:
php index.php -f /var/log/httpd/access-log